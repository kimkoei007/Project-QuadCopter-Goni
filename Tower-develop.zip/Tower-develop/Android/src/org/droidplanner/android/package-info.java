/**
 * Contains all the android specific functionality and user interface for the DroidPlanner
 * application.
 */
package org.droidplanner.android;