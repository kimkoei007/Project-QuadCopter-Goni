/**
 * Contains all the fragments used by the mission item's components.
 */
package org.droidplanner.android.proxy.mission.item.fragments;