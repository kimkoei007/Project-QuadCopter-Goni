/**
 * Contains code and logic related to the {@link org.droidplanner.core.mission.MissionItem} object.
 */
package org.droidplanner.android.proxy.mission.item;