/**
 * Contains adapters used to display/interact with the mission items.
 */
package org.droidplanner.android.proxy.mission.item.adapters;