package org.droidplanner.android.widgets.checklist.row;

public enum ListRow_Type {
	CHECKBOX_ROW, VALUE_ROW, TOGGLE_ROW, SWITCH_ROW, RADIO_ROW, SELECT_ROW, LEVEL_ROW, NOTE_ROW
}
