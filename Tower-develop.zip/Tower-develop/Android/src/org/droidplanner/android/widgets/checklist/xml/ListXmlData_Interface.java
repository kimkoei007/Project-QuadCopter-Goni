package org.droidplanner.android.widgets.checklist.xml;

public interface ListXmlData_Interface {
	public String getTagName();

	public int getDepth();

}
