/**
 * Contains logic to handle DroidPlanner's status bar notifications, and Android Wear functionality.
 */
package org.droidplanner.android.notifications;