package org.droidplanner.android.activities.interfaces;

/**
* Created by Fredia Huya-Kouadio on 1/23/15.
*/
public interface AccountLoginListener {
    public void onLogin();

    public void onFailedLogin();

    public void onLogout();
}
