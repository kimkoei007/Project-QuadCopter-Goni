package org.droidplanner.android.fragments.calibration;

import android.support.v4.app.Fragment;

public abstract class SetupSidePanel extends Fragment {
	public abstract void updateTitle(int idTitle);

	public abstract void updateDescription(int idDescription);

}
