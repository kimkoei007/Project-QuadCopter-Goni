package org.droidplanner.android.fragments.helpers;

/**
 * Created with IntelliJ IDEA. User: rgayle Date: 2013-10-07 Time: 12:30 AM To
 * change this template use File | Settings | File Templates.
 */
public interface GuidePointListener {
	void OnGuidePointMoved();
}
